import { Component, OnInit, EventEmitter  } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {FileDropDirective, FileSelectDirective} from "ng2-file-upload";
import {Observable} from "rxjs";
import {HttpClient} from "@angular/common/http";
import {FileUploader} from "ng2-file-upload";
import { UploadService,TokenStorageService } from '../services';

function readBase64(file): Promise<any> {
  var reader  = new FileReader();
  var future = new Promise((resolve, reject) => {
    reader.addEventListener("load", function () {
      resolve(reader.result);
    }, false);

    reader.addEventListener("error", function (event) {
      reject(event);
    }, false);

    reader.readAsDataURL(file);
  });
  return future;
}

@Component({
  selector: 'file-upload-form',
  templateUrl: './single-file-upload.component.html',
  styleUrls: ['./single-file-upload.component.css']
})
export class SingleFileUploadComponent implements OnInit {

  isMediaUploaded = false;
  uploadForm: FormGroup;
  public hasBaseDropZoneOver:boolean = false;
  public hasAnotherDropZoneOver:boolean = false;

  public uploader:FileUploader = new FileUploader({
    isHTML5: true  
  });

  

  constructor(private formgroup: FormBuilder, private http: HttpClient, private uploadService: UploadService, private tokenStorage: TokenStorageService) { 
    this.isMediaUploaded = false;
  }

  ngOnInit() {    
    this.uploadForm = this.formgroup.group({
      document: [null, null],
      type:  [null, null],
      title: [],
      description: [],
      tags: [],
    });

    this.uploader.onAfterAddingFile = f => {
      if (this.uploader.queue.length > 1) {
        this.uploader.removeFromQueue(this.uploader.queue[0]);
      }
    };


  //  this.uploader.onBuildItemForm = (fileItem: any, uploadForm: FormData): any => {
  //    uploadForm.append('file', fileItem);
  //    uploadForm.append('title', "Vinay");

   //   fileItem.withCredentials = false;
   //   return { fileItem, uploadForm };
   // };
  }

  uploadSubmit(){
    for (let i = 0; i < this.uploader.queue.length; i++) {
      let fileItem = this.uploader.queue[i]._file;
      if(fileItem.size > 200000000){
        alert("Each File should be less than 10 MB of size.");
        return;
      }
    }
    for (let j = 0; j < this.uploader.queue.length; j++) {
      let data = new FormData();
      let fileItem = this.uploader.queue[j]._file;
      console.log(fileItem.name.substr(fileItem.name.lastIndexOf('.')+1));
      data.append('file', fileItem);
      data.append('fileSeq', 'seq'+j);
      data.append('username', this.tokenStorage.getUsername());
      data.append( 'dataType', fileItem.name.substr(fileItem.name.lastIndexOf('.')+1));
      data.append( 'title', this.uploadForm.controls.title.value);
      data.append( 'description', this.uploadForm.controls.description.value);
      data.append( 'tag', this.uploadForm.controls.tags.value);
      this.uploadService.uploadFile(data).subscribe(
        data => {
          this.isMediaUploaded = true;
      },
      error => {
        console.log(error);        
      }
        
        );
    }
    this.uploader.clearQueue();
}


public fileOverBase(e:any):void {
  this.hasBaseDropZoneOver = e; 
}

public fileOverAnother(e:any):void {
  this.hasAnotherDropZoneOver = e;
}

public onFileSelected(event: EventEmitter<File[]>) {
  const file: File = event[0];

  console.log(file);

  readBase64(file)
    .then(function(data) {
    console.log(data);
  })

}

}
