import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FileEntity } from '../model';

@Injectable({
  providedIn: 'root'
})
export class UploadService {

  constructor(private http: HttpClient) { }

  uploadFile (data: FormData) {
   return this.http.post('http://localhost:38090/mediaapi/uploadFile', data);
   //return this.http.post('http://localhost:8020/uploadFile', data);
  }

  getUserMedia (username: String) {
    return this.http.get<FileEntity[]>('http://localhost:8020/mymedia/'+username);
  }

  uploadMultipleFiles (data: FormData[]) {
    return this.http.post('http://localhost:38090/mediaapi/uploadMultipleFiles', data);
   }

}
