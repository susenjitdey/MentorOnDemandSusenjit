import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../model';

@Injectable({
  providedIn: 'root'
})
export class FollowService {

 constructor(private http: HttpClient) { }
 
followUser(fromuser:String,touser:String){
        return this.http.post('http://localhost:38090/userapi/followuser',{user_from:fromuser,user_to:touser});
    }	

getFollowingList(user:String){
      return this.http.get<String[]>('http://localhost:38090/userapi/following/'+user);
  }	
}
