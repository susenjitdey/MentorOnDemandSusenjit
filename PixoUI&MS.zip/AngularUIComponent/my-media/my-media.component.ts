import { Component, OnInit } from '@angular/core';
import {MatDialogModule, MatDialog} from '@angular/material';
import {  MyDialogComponent} from '../my-dialog/my-dialog.component';
import { UploadService,TokenStorageService } from '../services';
import { FileEntity } from '../model/file-entity';

@Component({
  selector: 'app-my-media',
  templateUrl: './my-media.component.html',
  styleUrls: ['./my-media.component.css']
})
export class MyMediaComponent implements OnInit {
  private runsidebar:boolean;
  fileEntity: FileEntity[];
  text:String;
  
  constructor(public dialog: MatDialog,private uploadService: UploadService, private tokenService: TokenStorageService) { }

  ngOnInit() {
    this.runsidebar=true;
    this.uploadService.getUserMedia(this.tokenService.getUsername())
    .subscribe( data => {
      this.fileEntity = data;     
      console.log(this.fileEntity);
    });
  }

  display(pic:FileEntity):any
  {
    let dialogRef = this.dialog.open(MyDialogComponent, {
      //width: '600px',
      data: pic      
    });
    console.log("Clicked "+pic);
  }

}
