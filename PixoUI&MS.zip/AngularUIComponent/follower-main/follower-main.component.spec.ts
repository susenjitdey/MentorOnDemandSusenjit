import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FollowerMainComponent } from './follower-main.component';

describe('FollowerMainComponent', () => {
  let component: FollowerMainComponent;
  let fixture: ComponentFixture<FollowerMainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FollowerMainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FollowerMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
