import { Component, OnInit } from '@angular/core';
import {FollowService,UserService,TokenStorageService} from '../services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-follower-main',
  templateUrl: './follower-main.component.html',
  styleUrls: ['./follower-main.component.css']
})
export class FollowerMainComponent implements OnInit {
  userList: String[];
  runsidebar:boolean = false;
  constructor( private router: Router,private followService : FollowService,private userService : UserService,private tokenStorage: TokenStorageService) { }


  ngOnInit() {
    this.followService.getFollowingList(this.tokenStorage.getUsername())
    .subscribe( data => {
      this.userList = data; 
      console.log("data is ="+data);    
    });
  }

  FollowerMedia(username:string){
    this.tokenStorage.saveFollowerUsername(username);
    this.router.navigate(['/followermedia']);
  }

}
