import { Component, OnInit, Inject } from '@angular/core';
import {MAT_DIALOG_DATA} from '@angular/material';
import {MatDialogRef} from '@angular/material';
import {Comment} from '../model';
import {FileEntity} from '../model/file-entity';
import { CommentService,TokenStorageService } from '../services';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-my-dialog',
  templateUrl: './my-dialog.component.html',
  styleUrls: ['./my-dialog.component.css']
})
export class MyDialogComponent implements OnInit {
  commentForm: FormGroup;
  comments : Comment[];
 
  constructor(public thisDialogRef: MatDialogRef<MyDialogComponent>,private commentService : CommentService , private formBuilder: FormBuilder,private tokenStorage: TokenStorageService, @Inject(MAT_DIALOG_DATA) public data: FileEntity) 
  { 
    console.log("inside dialog "+data)
  }

  ngOnInit() {
    this.commentForm = this.formBuilder.group({
      comment: ['', Validators.required]
  });

    this.commentService.getmediacomment(this.data.id)
    .subscribe( data => {
      this.comments = data;     
    });
  }
  onCloseConfirm() {
    this.thisDialogRef.close('Confirm');
  }
  onCloseCancel() {
    this.thisDialogRef.close('Cancel');
  }
  close() {
    this.thisDialogRef.close();
  }

  addComments(fieId : number){
    this.commentService.savecomment(fieId,this.tokenStorage.getUsername(),this.commentForm.controls.comment.value)
    .subscribe( data => {
       this.commentService.getmediacomment(this.data.id)
        .subscribe( data => {
          this.comments = data;    
          this.commentForm.controls.comment.setValue(""); 
        }); 
    });
  }

  Testing() {
    console.log("I am in likecomment");
  }
  
  likeComment(comment : Comment){
    this.commentService.likecomment(comment.id)
    .subscribe( data => {
      this.commentService.getmediacomment(this.data.id)
      .subscribe( data => {
        this.comments = data;    
        this.commentForm.controls.comment.setValue(""); 
      });  
    });
  }

  unlikeComment(comment : Comment){
    this.commentService.unlikecomment(comment.id)
    .subscribe( data => {
      this.commentService.getmediacomment(this.data.id)
      .subscribe( data => {
        this.comments = data;    
        this.commentForm.controls.comment.setValue(""); 
      }); 
    });
  }
}