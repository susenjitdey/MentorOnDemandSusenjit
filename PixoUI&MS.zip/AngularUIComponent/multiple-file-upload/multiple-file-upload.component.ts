import { Component, OnInit, EventEmitter  } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {FileDropDirective, FileSelectDirective} from "ng2-file-upload";
import {Observable} from "rxjs";
import {HttpClient} from "@angular/common/http";
import {FileUploader} from "ng2-file-upload";
import { UploadService,TokenStorageService } from '../services';

function readBase64(file): Promise<any> {
  var reader  = new FileReader();
  var future = new Promise((resolve, reject) => {
    reader.addEventListener("load", function () {
      resolve(reader.result);
    }, false);

    reader.addEventListener("error", function (event) {
      reject(event);
    }, false);

    reader.readAsDataURL(file);
  });
  return future;
}

@Component({
  selector: 'file-upload-form',
  templateUrl: './multiple-file-upload.component.html',
  styleUrls: ['./multiple-file-upload.component.css']
})
export class MultipleFileUploadComponent implements OnInit {

  isMediaUploaded = false;
  title:String;
  uploadForm: FormGroup;
  public hasBaseDropZoneOver:boolean = false;
  public hasAnotherDropZoneOver:boolean = false;

  public uploader:FileUploader = new FileUploader({
    isHTML5: true  
  });

  

  

  constructor(private formgroup: FormBuilder, private http: HttpClient, private uploadService: UploadService,private tokenStorage: TokenStorageService) { }

  ngOnInit() {
    this.uploadForm = this.formgroup.group({
      document: [null, null],
      type:  [null, null],
      title1: [],
      description1: [],
      tags1: [],
      title2: [],
      description2: [],
      tags2: [],
      title3: [],
      description3: [],
      tags3: [],
    });

   


  this.uploader.onBuildItemForm = (fileItem: any, uploadForm: FormData): any => {
    uploadForm.append('file', fileItem);
    uploadForm.append('title', "Vinay");

    fileItem.withCredentials = false;
    return { fileItem, uploadForm };
   };
  }

  uploadSubmit(){
    let datalist :FormData[] = [];
    for (let i = 0; i < this.uploader.queue.length; i++) {
      let fileItem = this.uploader.queue[i]._file;
      if(fileItem.size > 200000000){
        alert("Each File should be less than 10 MB of size.");
        return;
      }
    }
    
    for (let j = 0; j < this.uploader.queue.length; j++) {
      let data = new FormData();
      let fileItem = this.uploader.queue[j]._file;
      console.log(fileItem.name);
      data.append('file', fileItem);
      data.append('username', this.tokenStorage.getUsername());
      data.append('fileSeq', 'seq'+j);
      data.append( 'dataType', fileItem.name.substr(fileItem.name.lastIndexOf('.')+1));
      if(j==0){
        data.append( 'title', this.uploadForm.controls.title1.value);
        data.append( 'description', this.uploadForm.controls.description1.value);
        data.append( 'tag', this.uploadForm.controls.tags1.value);
      }

      if(j==1){
        data.append( 'title', this.uploadForm.controls.title2.value);
        data.append( 'description', this.uploadForm.controls.description2.value);
        data.append( 'tag', this.uploadForm.controls.tags2.value);
      }

      if(j==2){
        data.append( 'title', this.uploadForm.controls.title3.value);
        data.append( 'description', this.uploadForm.controls.description3.value);
        data.append( 'tag', this.uploadForm.controls.tags3.value);
      }
      this.uploadService.uploadFile(data).subscribe(      
        data => {
         // this.isMediaUploaded = true;
       },
      error => {
        console.log(error);        
      }
        );  
      
    }

    console.log(datalist);
    

    this.uploader.clearQueue();
}


public fileOverBase(e:any):void {
  this.hasBaseDropZoneOver = e; 
}

public fileOverAnother(e:any):void {
  this.hasAnotherDropZoneOver = e;
}

public onFileSelected(event: EventEmitter<File[]>) {
  const file: File = event[0];

  console.log(file);

  readBase64(file)
    .then(function(data) {
    console.log(data);
  })

}

}
