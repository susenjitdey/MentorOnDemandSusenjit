import { Component, OnInit } from '@angular/core';
import {FollowService,UserService,TokenStorageService} from '../services';
import {User} from '../model';

@Component({
  selector: 'app-user-search',
  templateUrl: './user-search.component.html',
  styleUrls: ['./user-search.component.css']
})
export class UserSearchComponent implements OnInit {
  users: User[];

  constructor(private followService : FollowService,private userService : UserService,private tokenStorage: TokenStorageService) { }

  ngOnInit() {
    this.userService.getUsersList()
    .subscribe( data => {
      this.users = data;     
    });
  }

   Follow(touser:User): void {
    this.followService.followUser(this.tokenStorage.getUsername(),touser.username)
    .subscribe( data => {
      this.users = this.users.filter(t => t !== touser);
    })
  };


}
