import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'media-upload-main',
  templateUrl: './media-upload-main.component.html',
  styleUrls: ['./media-upload-main.component.css']
})
export class MediaUploadMainComponent implements OnInit {
  runsidebar:boolean = true;
  constructor() { }

  ngOnInit() {
  }

}
