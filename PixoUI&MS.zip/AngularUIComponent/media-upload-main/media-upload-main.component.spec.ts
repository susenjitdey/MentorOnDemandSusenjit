import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MediaUploadMainComponent } from './media-upload-main.component';

describe('MediaUploadMainComponent', () => {
  let component: MediaUploadMainComponent;
  let fixture: ComponentFixture<MediaUploadMainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MediaUploadMainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MediaUploadMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
