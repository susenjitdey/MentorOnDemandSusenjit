import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FollowerMediaComponent } from './follower-media.component';

describe('FollowerMediaComponent', () => {
  let component: FollowerMediaComponent;
  let fixture: ComponentFixture<FollowerMediaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FollowerMediaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FollowerMediaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
