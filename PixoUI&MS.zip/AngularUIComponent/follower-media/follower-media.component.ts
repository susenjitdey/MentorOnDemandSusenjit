import { Component, OnInit } from '@angular/core';
import {MatDialogModule, MatDialog} from '@angular/material';
import {  MyDialogComponent} from '../my-dialog/my-dialog.component';
import { UploadService,TokenStorageService } from '../services';
import { FileEntity } from '../model/file-entity';

@Component({
  selector: 'app-follower-media',
  templateUrl: './follower-media.component.html',
  styleUrls: ['./follower-media.component.css']
})
export class FollowerMediaComponent implements OnInit {
private runsidebar:boolean;
  fileEntity: FileEntity[];
  text:String;
constructor(public dialog: MatDialog,private uploadService: UploadService, private tokenService: TokenStorageService) { }

  ngOnInit() {
    this.runsidebar=true;
    this.uploadService.getUserMedia(this.tokenService.getFollowerUsername())
    .subscribe( data => {
      this.fileEntity = data;     
    });
  }

  display(pic:FileEntity):any
  {
    let dialogRef = this.dialog.open(MyDialogComponent, {
      //width: '600px',
      data: pic      
    });
    console.log("Clicked "+pic);
  }

}
