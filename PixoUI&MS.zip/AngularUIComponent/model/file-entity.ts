export class FileEntity{
    id: number;
    username: string;
    filename: string;
    location: string;
    hidden: string;
    dataType: string;
	title: string;
	description: string;
	tags:string;
	likes:string;
}