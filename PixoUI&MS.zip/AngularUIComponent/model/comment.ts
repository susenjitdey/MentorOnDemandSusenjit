export class Comment {
    id: number;
    fileItemEntityId: number;
    commentByUser: string;
    description: string;
    like: string;
    unlike: string;
}