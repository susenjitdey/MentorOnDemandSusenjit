package com.fsd.pixogram.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.fsd.pixogram.model.Comment;

public interface CommentRepository extends JpaRepository<Comment, Long> {
	
   List<Comment> findByFileItemEntityId(long fieId);
   
   @Transactional
   @Modifying
   @Query("UPDATE Comment c SET likeCount =:likecount where id=:id")
   void likecomment(@Param("id") Long id,@Param("likecount") String likecount);
   
   @Transactional
   @Modifying
   @Query("UPDATE Comment c SET unlikeCount =:unlikecount where id=:id")
   void unlikecomment(@Param("id") Long id,@Param("unlikecount") String unlikecount);
	

}
