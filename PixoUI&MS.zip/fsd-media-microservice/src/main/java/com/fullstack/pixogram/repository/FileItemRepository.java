package com.fsd.pixogram.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fsd.pixogram.model.FileItemEntity;
import java.lang.String;
import java.util.List;

public interface FileItemRepository extends JpaRepository<FileItemEntity, Long> {
 List<FileItemEntity> findByUsername(String username);
	
}
