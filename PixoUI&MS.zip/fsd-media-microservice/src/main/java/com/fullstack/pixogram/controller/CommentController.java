package com.fsd.pixogram.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fsd.pixogram.model.Comment;
import com.fsd.pixogram.service.CommentService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class CommentController {	
	
	@Autowired
	private CommentService commentService;
	
	 private static final Logger logger = LoggerFactory.getLogger(CommentController.class);
	 
	 
	 
	 @RequestMapping(value = "/comments/{fieId}", method = RequestMethod.GET)
	    public List<Comment> mediaComments(@PathVariable(value = "fieId") Long fieId){
		 return commentService.findAllCommentByMedia(fieId);
	 }
	 
	 @RequestMapping(value = "/savecomment", method = RequestMethod.POST)
	  public void saveComments(@RequestBody Comment comment){
		 commentService.saveComment(comment);
	 }
	 
	 @RequestMapping(value = "/likecomment", method = RequestMethod.POST)
	  public void likeComment(@RequestBody Comment comment){
		 commentService.likeComment(comment.getId());
	 }
	 
	 @RequestMapping(value = "/unlikecomment", method = RequestMethod.POST)
	  public void unlikeComment(@RequestBody Comment comment){
		 commentService.unlikeComment(comment.getId());
	 }

}
