package com.fsd.pixogram.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fsd.pixogram.model.Comment;
import com.fsd.pixogram.repository.CommentRepository;

@Service
public class CommentService {
	
	@Autowired
	private CommentRepository commentRepo;
	
	public List<Comment> findAllCommentByMedia(long mediaId){
		return commentRepo.findByFileItemEntityId(mediaId);
	}

	public void saveComment(Comment comment) {
		commentRepo.save(comment);
	}

	public void likeComment(Long commentid) {
		String likecount;
		String currentLikeCount = commentRepo.getOne(commentid).getLikeCount();
		if(currentLikeCount ==null) {
			likecount ="1";
		}else {
			likecount = String.valueOf(Integer.valueOf(currentLikeCount)+1);
		}
		commentRepo.likecomment(commentid,likecount);
		
	}

	public void unlikeComment(Long commentid) {	
		String unlikecount;
		String currentunLikeCount = commentRepo.getOne(commentid).getUnlikeCount();
		if(currentunLikeCount ==null) {
			unlikecount ="1";
		}else {
			unlikecount = String.valueOf(Integer.valueOf(currentunLikeCount)+1);
		}
		commentRepo.unlikecomment(commentid,unlikecount);
		
	}

}
