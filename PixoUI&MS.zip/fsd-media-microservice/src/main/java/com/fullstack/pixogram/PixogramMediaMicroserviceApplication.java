package com.fsd.pixogram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.fsd.pixogram.util.FileStorageProperties;

@SpringBootApplication
@EnableConfigurationProperties({
    FileStorageProperties.class
})
public class PixogramMediaMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PixogramMediaMicroserviceApplication.class, args);
	}

}
