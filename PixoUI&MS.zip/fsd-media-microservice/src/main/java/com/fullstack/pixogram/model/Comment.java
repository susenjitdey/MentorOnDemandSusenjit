package com.fsd.pixogram.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "comment")
public class Comment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column
	private long fileItemEntityId;
	
	@Column
	private String commentByUser;
	
	@Column
	private String description;
	
	@Column
	private String likeCount;
	
	@Column
	private String unlikeCount;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getFileItemEntityId() {
		return fileItemEntityId;
	}

	public void setFileItemEntityId(long fileItemEntityId) {
		this.fileItemEntityId = fileItemEntityId;
	}

	public String getCommentByUser() {
		return commentByUser;
	}

	public void setCommentByUser(String commentByUser) {
		this.commentByUser = commentByUser;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLikeCount() {
		return likeCount;
	}

	public void setLikeCount(String likeCount) {
		this.likeCount = likeCount;
	}

	public String getUnlikeCount() {
		return unlikeCount;
	}

	public void setUnlikeCount(String unlikeCount) {
		this.unlikeCount = unlikeCount;
	}

}
